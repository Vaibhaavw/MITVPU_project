from django.db import models
from django.contrib.auth.models import User


# Create your models here.
class Student(models.Model):
    counselor_name = models.CharField(max_length=100)
    team_leader = models.CharField(max_length=100)
    enrolled_month = models.CharField(max_length=20)
    enrolled_date = models.DateField()
    student_name = models.CharField(max_length=255)
    student_mobile = models.CharField(max_length=15)
    student_email = models.EmailField()
    course_program = models.CharField(max_length=255)
    specialization = models.CharField(max_length=255)
    application_status = models.CharField(max_length=50)
    application_submit_date = models.DateField()
    program_fees = models.DecimalField(max_digits=10, decimal_places=2)
    fee_paid = models.DecimalField(max_digits=10, decimal_places=2)
    payment_mode = models.CharField(max_length=50)
    transaction_id = models.CharField(max_length=100, null=True, blank=True)
    utr = models.CharField(max_length=100, null=True, blank=True)
    scholarship = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    lead_creation_date = models.DateField(null=True, blank=True)
    source = models.CharField(max_length=100,null=True, blank=True)
    
    def __str__(self):
      return self.student_name
