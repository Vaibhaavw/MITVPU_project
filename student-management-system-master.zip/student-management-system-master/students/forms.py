from django import forms
from .models import Student


class StudentForm(forms.ModelForm):
  class Meta:
    model = Student
    fields = [
            'counselor_name',
            'team_leader',
            'enrolled_month',
            'enrolled_date',
            'student_name',
            'student_mobile',
            'student_email',
            'course_program',
            'specialization',
            'application_status',
            'application_submit_date',
            'program_fees',
            'fee_paid',
            'payment_mode',
            'transaction_id',
            'utr',
            'scholarship',
            'lead_creation_date',
            'source'
        ]
    labels = {
      'counselor_name': 'Counselor Name',
      'team_leader': 'Team Leader',
      'enrolled_month': 'Enrolled Month',
      'enrolled_date': 'Enrolled Date',
      'student_name': 'StudentName',
      'student_mobile': 'Student Mobile',
      'student_email': 'Student Email',
      'course_program': 'Course Program',
      'specialization': 'Specialization',
      'application_status': 'Application Status',
      'application_submit_date': 'Application Submit Date',
      'program_fees': 'Program Fees',
      'fee_paid': 'Fee Paid',
      'payment_mode': 'Payment Mode',
      'transaction_id': 'Transaction Id',
      'utr': 'UTR',
      'scholarship': 'Scholarship',
      'lead_creation_date': 'Lead Creation Date',
      'source': 'source',
    }
    widgets = {
            'counselor_name': forms.TextInput(attrs={'class': 'form-control'}),
            'team_leader': forms.TextInput(attrs={'class': 'form-control'}),
            'enrolled_month': forms.TextInput(attrs={'class': 'form-control'}),
            'enrolled_date': forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'student_name': forms.TextInput(attrs={'class': 'form-control'}),
            'student_mobile': forms.TextInput(attrs={'class': 'form-control'}),
            'student_email': forms.EmailInput(attrs={'class': 'form-control'}),
            'course_program': forms.TextInput(attrs={'class': 'form-control'}),
            'specialization': forms.TextInput(attrs={'class': 'form-control'}),
            'application_status': forms.TextInput(attrs={'class': 'form-control'}),
            'application_submit_date': forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'program_fees': forms.NumberInput(attrs={'class': 'form-control'}),
            'fee_paid': forms.NumberInput(attrs={'class': 'form-control'}),
            'payment_mode': forms.TextInput(attrs={'class': 'form-control'}),
            'transaction_id': forms.TextInput(attrs={'class': 'form-control'}),
            'utr': forms.TextInput(attrs={'class': 'form-control'}),
            'scholarship': forms.NumberInput(attrs={'class': 'form-control'}),
            'lead_creation_date': forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'source': forms.TextInput(attrs={'class': 'form-control'})
    }


    transaction_id = forms.CharField(required=False, widget=forms.TextInput(attrs={'class': 'form-control'}))
    utr = forms.CharField(required=False, widget=forms.TextInput(attrs={'class': 'form-control'}))