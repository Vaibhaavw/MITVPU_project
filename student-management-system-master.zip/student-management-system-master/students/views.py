from django.http import HttpResponseRedirect
from django.shortcuts import render
from django.urls import reverse
from .models import Student
from .forms import StudentForm


# Create your views here.
def index(request):
  return render(request, 'students/index.html', {
    'students': Student.objects.all()
  })


def view_student(request, id):
  return HttpResponseRedirect(reverse('index'))


def add(request):
    if request.method == 'POST':
        form = StudentForm(request.POST)
        if form.is_valid():
            # Capture all cleaned data from the form
            cleaned_data = form.cleaned_data

            # Create a new Student object with the cleaned data
            new_student = Student(
                counselor_name=cleaned_data['counselor_name'],
                team_leader=cleaned_data['team_leader'],
                enrolled_month=cleaned_data['enrolled_month'],
                enrolled_date=cleaned_data['enrolled_date'],
                student_name=cleaned_data['student_name'],
                student_mobile=cleaned_data['student_mobile'],
                student_email=cleaned_data['student_email'],
                course_program=cleaned_data['course_program'],
                specialization=cleaned_data['specialization'],
                application_status=cleaned_data['application_status'],
                application_submit_date=cleaned_data['application_submit_date'],
                program_fees=cleaned_data['program_fees'],
                fee_paid=cleaned_data['fee_paid'],
                payment_mode=cleaned_data['payment_mode'],
                transaction_id=cleaned_data['transaction_id'],
                utr=cleaned_data['utr'],
                scholarship=cleaned_data['scholarship'],
                lead_creation_date=cleaned_data['lead_creation_date'],
                source=cleaned_data['source']
            )
            new_student.save()

            # Redirect to the index page or another page after successful addition
            return render(request, 'students/add.html', {
                'form': StudentForm(),  # Render a new, empty form
                'success': True
            })

    else:
        form = StudentForm()

    return render(request, 'students/add.html', {
        'form': form
    })


def edit(request, id):
  if request.method == 'POST':
    student = Student.objects.get(pk=id)
    form = StudentForm(request.POST, instance=student)
    if form.is_valid():
      form.save()
      return render(request, 'students/edit.html', {
        'form': form,
        'success': True
      })
  else:
    student = Student.objects.get(pk=id)
    form = StudentForm(instance=student)
  return render(request, 'students/edit.html', {
    'form': form
  })


def delete(request, id):
  if request.method == 'POST':
    student = Student.objects.get(pk=id)
    student.delete()
  return HttpResponseRedirect(reverse('index'))
