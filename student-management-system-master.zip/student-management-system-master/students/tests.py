import random
from django.test import TestCase
from .models import Student
from django.urls import reverse
from django.utils import timezone


class StudentModelUnitTestCase(TestCase):
    def setUp(self):
        self.student = Student.objects.create(
            counselor_name='Alice Johnson',
            team_leader='David Brown',
            enrolled_month='August',
            enrolled_date=timezone.now().date(),
            student_name='John Doe',
            student_mobile='1234567890',
            student_email='john.doe@test.com',
            course_program='Engineering',
            specialization='Mechanical',
            application_status='Approved',
            application_submit_date=timezone.now().date(),
            program_fees=1500.00,
            fee_paid=500.00,
            payment_mode='Credit Card',
            transaction_id='TX123456',
            utr='UTR123456',
            scholarship=200.00,
            lead_creation_date=timezone.now().date(),
            source='Referral'
        )

    def test_student_model(self):
        data = self.student
        self.assertIsInstance(data, Student)
